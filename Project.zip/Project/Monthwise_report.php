<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthwise report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"type="text/css" href="expencestyle.css">
</head>

<body>
    <header class="container-fluid banner">

        <div class="row">
            <div class="col-sm-12 py-3">
              <?php include 'header.php'  ?>
            </div>

        </div>
    </header>
    <section class="container-fluid">

        <div class="row justify-content-center">
            

            <div class="col-sm-2 menu">
              <?php include 'sidebar.php'  ?> 
            </div>
            <div class="col-sm-10 content">
                 <div class="container maincontent">
                    <form method="post">
                   

                        <label>Start Month </label><br>
                        <input type="month" name="s_month"class="form-control"required><br>

                         <label>End Month</label><br>
                        <input type="month" name="E_month"class="form-control"required><br>

                         <input type="submit"class="btn btn1"value="Show report"name="sh_m_report">
                    </form>
                     <?php
                    if(isset($_POST['sh_m_report'])){
                        $smonth = $_POST['s_month'] . '-01';
                        $emonth = $_POST['E_month'] . '-31';
                        $uid = $_SESSION['uid'];
                        $con = mysqli_connect("localhost","root","","dets_db");
                        $qry = "select * from tblexpense where userid = $uid and expensedate between '$smonth' and '$emonth'";
                        $result = mysqli_query($con, $qry);
                        if(mysqli_num_rows($result)>0){
                            echo "<table class='table  table-striped'>";
                            echo "<tr style='background-color: rosybrown; color: white'>";
                            echo "<th>Expense Date</th>";
                            echo "<th>Categorie</th>";
                            echo "<th>Expense Item Name</th>";
                            echo "<th>Expense Amount</th>";
                            echo "</tr>";
                            $total = 0;
                            while($row = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>$row[2]</td>";
                                echo "<td>$row[3]</td>";
                                echo "<td>$row[4]</td>";
                                echo "<td>$row[5]</td>";
                                $total += $row[5];
                                echo "</tr>";
                            }
                            echo "<tr style='background-color: rosybrown; color: white; text-weight:bold; text-align:center'>";
                            echo "<td colspan='4''>Total Amount : $total</td>";
                            echo "</tr>";
                            echo "</table>";
                        }
                        else{
                            echo "<h3 class='text-warning'>No Record Found !!!</h3>";
                        }
                        mysqli_close($con);
                    }
                ?>
                 </div>
            </div>

        </div>
    </section>
    <footer class="container-fluid foot">
       <?php include 'footer.php'  ?>
    </footer>

</body>

</html>