<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add expense</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"type="text/css" href="expencestyle.css">
</head>

<body>
    <header class="container-fluid banner">

        <div class="row">
            <div class="col-sm-12 py-3">
              <?php include 'header.php'  ?>
            </div>

        </div>
    </header>
    <section class="container-fluid">

        <div class="row justify-content-center">
            

            <div class="col-sm-2 menu">
              <?php include 'sidebar.php'  ?> 
            </div>
            <div class="col-sm-10 content">
                <div class="container maincontent">
                    <form method="post">
                        <h3>Add Expense</h3>

                        <label>Select Date</label><br>
                        <input type="date" name="txtdate"class="form-control"required><br>
                         <label>Categories</label><br>
                         <select class="form-control" name="categ"required>
                            <option></option>
                            <option>Travel</option>
                            <option>Food</option>
                            <option>Medicine</option>
                            <option>Rent</option>
                            <option>Fee</option>
                            <option>Groceries</option>
                            <option>Apparel & Footware</option>
                            <option>Stationery</option>
                            <option>Entertainment</option>

                         </select><br>

                          <label>Expense item Name's</label><br>
                        <input type="text" name="item"placeholder="item name here"class="form-control input1"required>


                        <br>

                          <label>Expense Cost</label><br>
                        <input type="text" name="price"placeholder="Price Here"class="form-control"required>
                        <input type="submit"class="btn btn1"value="Add Expense Detail"name="Addbtn">
                    </form>
                    <?php
                    if(isset($_POST['Addbtn'])) 
                    {
                        $date = $_POST['txtdate'];
                        $cat = $_POST['categ'];
                        $item = $_POST['item'];
                        $cost = $_POST['price'];
                        $uid = $_SESSION['uid'];


                        $con = mysqli_connect("localhost","root","","dets_db");
                        $qry = "insert into tblexpense (userid,Expensedate, categoryname,Expenseitem,Expensecost) values  ($uid, '$date', '$cat', '$item', $cost)";

                         mysqli_query($con, $qry);

                          if (mysqli_affected_rows($con) > 0)
                              echo "<p class='text-success'>Expense Added Successfully !!!!</p>";
                          else
                              echo "<p class='text-danger'>Error in adding the expense !!!!</p>";
                         
                          mysqli_close($con);
                         
                         
                         


                    } 
                    
                    ?>
                </div>
            </div>

        </div>
    </section>
    <footer class="container-fluid foot">
       <?php include 'footer.php'  ?>
    </footer>

</body>

</html>