<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        
        body{
            display: flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            background-image:url('https://img.magnific.com/premium-photo/close-up-glass-wall-with-blue-sky-background_1028873-111858.jpg?semt=ais_hybrid&w=740&q=80');
            background-repeat:no-repeat;
            background-size:cover;
            background-possition:center;


        }
         .heading1 {
            border:1px solid rgba(12,25,45,.75);
            border-radius:1px solid rgba(255,255,255,0.25);
            padding:20px 30px;
            backdrop-filter:blur(18px);

          
        }
        .heading1 h2{
            color:#ffffff;
        }
        .heading1 h2 span{
    color:#00BFFF;
}

       
       .input1{
         background:rgba(255,255,255,.12);
       border:1px solid #38BDF8;
    color:#ffffff;

        margin:5px;
       }
       .input1::placeholder{
            color:aqua;
       }
       .btn2{
        width:100%;
        color:white;
         background:linear-gradient(135deg,#0284C7,#0EA5E9);
        border:1px solid black;
        margin-top:10px;
       }
       .btn2:hover{
       background:linear-gradient(135deg,#0369A1,#0284C7);
        box-shadow:0 0 18px rgba(14,165,233,.6);

       }
       a{
        text-decoration:none;
        
    color:#E0F2FE;
        
        text-align:center;
       }
       a:hover{
           color:#38BDF8;
       }
    </style>
</head>
<body>
    <div class="heading1">
        
        <h2>Create New Account</h2>
        
    <form method="post" onsubmit="return vaildate()">
        <div class="form-group">
            <?php

            if(isset($_POST['reg'])){
                $name=$_POST['txtname'];
                $email=$_POST['txtemail'];
                $number=$_POST['txtnumber'];
                $password=$_POST['txtpass'];
                $rdate=date("d-m-y h:i:s a");
                $conn = mysqli_connect("localhost","root","","dets_db");
                $query = "insert into tbluser(fullname,email,mobilenumber,password, regdate) values('$name', '$email' , '$number' , '$password','$rdate')";

               mysqli_query($conn,$query);

                if(mysqli_affected_rows($conn)>0)
                    echo "<p>sign up successfully</p>";
                else
                      echo "<p>Error in signup process !!! Try Again. </p>";

            }
            ?>
        </div>
        
        <input type="text"name="txtname"placeholder="Full Name"class="form-control input1"required>

         <br>
        <input id="a1" type="email"name="txtemail"placeholder="Email"class="form-control input1"required>
         <br>
        <input id="a2" type="number"name="txtnumber"placeholder="Mobile Number"class="form-control input1"required>
         <br>
        <input id="a3" type="password"name="txtpass"placeholder="Password"class="form-control input1"required>
         <br>
        <input id="a4" type="password"name="txtcpass"placeholder="Confirm Password"class="form-control input1"required>


       

        <b><input class="btn btn2" type="submit"value="Register"name="reg"></b>
<div class="text-center mt-5">
        <a href="login.php">Go to Login Page</a>
        </div>
    </form>
    
       <script>
function vaildate() {
    let status = true;

    let no = document.getElementById("a2");
    let p1 = document.getElementById("a3");
    let p2 = document.getElementById("a4");

    
    if (no.value.length == 10 &&
        no.value >= 6000000000 &&
        no.value <= 9999999999) {

        no.style.border = "";
    } else {
        no.style.border = "3px solid red";
        status = false;
    }

    
    if (p1.value == p2.value) {
        p1.style.border = "";
        p2.style.border = "";
    } else {
        p1.style.border = "3px solid red";
        p2.style.border = "3px solid red";
        status = false;
    }

    return status;
}
</script>

    
    </div>
</body>
</html>