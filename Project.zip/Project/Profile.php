<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:login.php");
}
$con = mysqli_connect("localhost", "root","","dets_db");
    if(isset($_POST['btnupdate'])){
        $name = $_POST['txtfname'];
        $no = $_POST['txtnum'];
        $qry = "update tbluser set fullname='$name', MobileNumber=$no where userid=$_SESSION[uid]";
        mysqli_query($con, $qry);
    }
        $qry = "select * from tbluser where userid = $_SESSION[uid]";
        $result = mysqli_query($con, $qry);
        $row = mysqli_fetch_array($result);
        $_SESSION['name'] = $row[1];
    
    mysqli_close($con);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>profile</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"type="text/css" href="expencestyle.css">
</head>

<body>
    <header class="container-fluid banner">

        <div class="row">
            <div class="col-sm-12 py-3">
              <?php include 'header.php'  ?>
            </div>

        </div>
    </header>
    <section class="container-fluid">

        <div class="row justify-content-center">
            

            <div class="col-sm-2 menu">
              <?php include 'sidebar.php'  ?> 
            </div>
            <div class="col-sm-10 content">
                 <div class="container maincontent">
                    <form method="post">
                        <h3>User Profile</h3>

                        <label>Full Name</label><br>
                        <input type="text" name="txtfname"placeholder="Enter Full Name"class="form-control"value="<?php if(isset($row[1])) echo $row[1]; ?>"required><br>

                          <label>Email ID</label><br>
                        <input type="email" name="email"placeholder="Enter Email ID"class="form-control"value="<?php if(isset($row[2])) echo $row[2];?>"required>


                        <br>

                          <label>Mobile Number</label><br>
                        <input type="number" name="txtnum"placeholder="Enter Mobile Number"class="form-control"value="<?php if(isset($row[3])) echo $row[3];?>"required>
                        <input type="submit"class="btn btn1"value="Update profile"name="btnupdate">
                    </form>
                </div>

        </div>
    </section>
    <footer class="container-fluid foot">
       <?php include 'footer.php'  ?>
    </footer>

</body>

</html>