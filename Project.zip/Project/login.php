<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body{
            display: flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            background-image:url('https://img.magnific.com/premium-photo/close-up-glass-wall-with-blue-sky-background_1028873-111858.jpg?semt=ais_hybrid&w=740&q=80');
            background-repeat:no-repeat;
            background-size:cover;
            background-possition:center;


        }
         .heading {
            border:1px solid rgba(12,25,45,.75);
            border-radius:10px;
            padding:20px;
            backdrop-filter:blur(18px);
          
        }
       h2{
       color:#ffffff;

        text-align:center;
       }
       h2{
        span{
                color:#00E5FF;
        }
       }
       label{
            color:blue;
       }
       .input{
         background-color:rgba(255,255,255,0.12);
    border:1px solid #00BCD4;
    color:#ffffff;
        margin:5px;
       }
       .input::placeholder{
            color:cyan;
       }
       .btn1{
        width:100%;
         color:white;
    background:#1565C0;
        border:1px solid black;
         margin-top:10px;
       }
       .btn1:hover{
            background:#0D47A1;
       box-shadow:0 10px 20px rgba(13,71,161,0.5);

       }
       a{
        text-decoration:none;
          color:#BBDEFB;
        
        text-align:center;
       }
       a:hover{
           color:#00E5FF;
       }
    </style>
</head>
<body>
    <div class="heading">
        
        <h2>EXPENSE <span>TRACKING</span> <p>SYSTEM</p></h2>
        
    <form method="post">
        <div class="form_group">
        <?php
        if(isset($_POST['loginbtn']))
            {
            $username=$_POST['txtuname'];
             $password=$_POST['txtpwd'];
             $con = mysqli_connect("localhost","root","","dets_db");
             $query = "select * from tbluser where email='$username'and password='$password'";
             $result = mysqli_query($con,$query);
              if(mysqli_num_rows($result)>0){
                $row = mysqli_fetch_array($result);
                session_start();
                $_SESSION['uid']=$row[0];
                $_SESSION['name']=$row[1];
                header("location:dashboard.php");
             }
             else{
                echo("invalid username & password");
             }
             mysqli_close($con);

        }

        ?>
        </div>
        <label>User name</label><br>
        <input type="email"placeholder="Enter Email Here"name="txtuname"class="form-control input"required><br>

         <label>Password</label><br>
        <input type="password"placeholder="Enter Password Here"name="txtpwd"class="form-control input"required>

        <input type="checkbox"value="check"name="Remember me"><label> Remember me !!!</label>

        <b><input class="btn btn1" type="submit"value="Login"name="loginbtn"></b>
<div class="text-center mt-5">
        <a href="register.php">New User CLICK Here !!!</a>
        </div>
    </form>
    </div>
</body>
</html>